import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Gift, Coffee, ShoppingBag, Bus, Ticket, Utensils } from "lucide-react"

// Define available rewards
const rewards = [
  {
    id: "coffee",
    name: "Coffee Voucher",
    points: 100,
    description: "Free coffee at the campus cafe",
    icon: Coffee,
  },
  {
    id: "store",
    name: "Campus Store Discount",
    points: 150,
    description: "10% off at the campus store",
    icon: ShoppingBag,
  },
  {
    id: "transport",
    name: "Free Bus Pass",
    points: 300,
    description: "One-day free public transportation",
    icon: Bus,
  },
  {
    id: "movie",
    name: "Movie Ticket",
    points: 500,
    description: "Free movie ticket at the local cinema",
    icon: Ticket,
  },
  {
    id: "meal",
    name: "Cafeteria Meal",
    points: 250,
    description: "Free meal at the campus cafeteria",
    icon: Utensils,
  },
]

export default function RewardsPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-green-50 to-green-100">
      <main className="flex-1 container max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <Link href="/recycle">
            <Button variant="ghost" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Recycling
            </Button>
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h1 className="text-2xl font-bold text-green-800 flex items-center gap-2 mb-6">
            <Gift className="h-6 w-6" />
            Available Rewards
          </h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rewards.map((reward) => (
              <Card key={reward.id} className="border-green-200">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <reward.icon className="h-5 w-5 text-green-600" />
                    {reward.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{reward.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between items-center pt-2">
                  <p className="font-bold text-green-700">{reward.points} points</p>
                  <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50">
                    Redeem
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="mt-8 p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="text-center text-gray-600">
              Note: This is a static display for the MVP version. Actual redemption functionality will be implemented in
              future versions.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
