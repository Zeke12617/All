"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Trash2, Recycle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Define recycling types with their point values
const recyclingTypes = [
  { id: "paper", name: "Paper", points: 5, icon: "📄" },
  { id: "plastic", name: "Plastic", points: 8, icon: "🥤" },
  { id: "metal", name: "Metal", points: 10, icon: "🥫" },
  { id: "glass", name: "Glass", points: 7, icon: "🍶" },
  { id: "electronic", name: "Electronic Waste", points: 15, icon: "💻" },
  { id: "organic", name: "Organic Waste", points: 3, icon: "🍎" },
]

export default function RecyclePage() {
  const [totalPoints, setTotalPoints] = useState(0)
  const [gainedPoints, setGainedPoints] = useState(0)
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { toast } = useToast()

  // Load points from localStorage on component mount
  useEffect(() => {
    const savedPoints = localStorage.getItem("ecoPoints")
    if (savedPoints) {
      setTotalPoints(Number.parseInt(savedPoints))
    }
  }, [])

  // Save points to localStorage when they change
  useEffect(() => {
    localStorage.setItem("ecoPoints", totalPoints.toString())
  }, [totalPoints])

  const handleRecycleSelect = (typeId: string) => {
    const selectedRecyclingType = recyclingTypes.find((type) => type.id === typeId)

    if (selectedRecyclingType) {
      setSelectedType(typeId)
      setGainedPoints(selectedRecyclingType.points)

      // Update total points
      setTotalPoints((prev) => prev + selectedRecyclingType.points)

      // Show success toast
      toast({
        title: "Recycling Successful!",
        description: `You earned ${selectedRecyclingType.points} points for recycling ${selectedRecyclingType.name.toLowerCase()}.`,
        duration: 3000,
      })

      // Reset selection after a delay
      setTimeout(() => {
        setSelectedType(null)
        setGainedPoints(0)
      }, 2000)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-green-50 to-green-100">
      <main className="flex-1 container max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>

          <Link href="/rewards">
            <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50">
              View Rewards
            </Button>
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-4">
            <h1 className="text-2xl font-bold text-green-800 flex items-center gap-2">
              <Recycle className="h-6 w-6" />
              Select Recycling Type
            </h1>

            <div className="flex items-center gap-4">
              <div className="bg-green-100 rounded-lg px-4 py-2">
                <p className="text-sm text-green-700">Gained Points</p>
                <p className="text-xl font-bold text-green-800">+{gainedPoints}</p>
              </div>

              <div className="bg-green-600 text-white rounded-lg px-4 py-2">
                <p className="text-sm">Total Points</p>
                <p className="text-xl font-bold">{totalPoints}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {recyclingTypes.map((type) => (
              <Card
                key={type.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedType === type.id ? "ring-2 ring-green-500 bg-green-50" : ""
                }`}
                onClick={() => handleRecycleSelect(type.id)}
              >
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <div className="text-4xl mb-2">{type.icon}</div>
                  <h3 className="font-medium">{type.name}</h3>
                  <p className="text-green-700 font-bold">+{type.points} points</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold text-green-800 mb-4 flex items-center gap-2">
            <Trash2 className="h-5 w-5" />
            How to Recycle Properly
          </h2>

          <div className="space-y-3 text-gray-600">
            <p>• Clean and dry all recyclables before disposal</p>
            <p>• Remove caps and lids from bottles</p>
            <p>• Flatten cardboard boxes to save space</p>
            <p>• Separate different types of materials</p>
            <p>• Check local recycling guidelines for specific instructions</p>
          </div>
        </div>
      </main>
    </div>
  )
}
