import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Leaf } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-green-50 to-green-100">
      <main className="flex-1 container max-w-4xl mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-center space-y-8 text-center py-12 md:py-24">
          <div className="bg-white p-6 rounded-full shadow-md">
            <Leaf className="h-16 w-16 text-green-500" />
          </div>

          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl text-green-800">EcoPoints</h1>

          <p className="max-w-[700px] text-lg text-gray-600 md:text-xl">
            Welcome to EcoPoints! Start recycling today and earn points that you can redeem for rewards.
          </p>

          <div className="space-y-4 w-full max-w-sm">
            <Link href="/recycle" className="w-full">
              <Button className="w-full text-lg py-6 bg-green-600 hover:bg-green-700">Start Recycling</Button>
            </Link>

            <Link href="/login" className="w-full">
              <Button
                variant="outline"
                className="w-full text-lg py-6 border-green-600 text-green-700 hover:bg-green-50"
              >
                Login
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t border-green-200 bg-white py-6">
        <div className="container mx-auto px-4 text-center text-sm text-gray-500">
          <p>© 2025 EcoPoints. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
